using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Threading.Tasks;
using TaxInterviewQuestion.Data.Entities;
using Taxjar;
using TaxInterviewQuestion.Service;
using TaxInterviewQuestion.Core.Extensions;
using System;

namespace TaxInterviewQuestion.UnitTest
{
    [TestClass]
    public class TaxUnitTests
    {
        public List<Taxjar.RateResponseAttributes> responseRateList = new List<Taxjar.RateResponseAttributes>();
        public List<Taxjar.TaxResponseAttributes> responseTaxList = new List<Taxjar.TaxResponseAttributes>();
        private List<SalesOrder> orderList = new List<SalesOrder>();

        private List<Location> locationList = new List<Location>();

        [TestMethod]
        public async Task TestRateByLocation()
        {
            // Arrange: Populate our fake locations and create our client consumer
            PopulateLocalListOfFakeLocations();
            TaxServices service = new TaxServices();

            // Act: Run through all of our test cases by calling the service
            try
            {
                foreach (var location in locationList)
                {
                    Taxjar.RateResponseAttributes result = await service.GetTaxRateForLocation(location);
                    responseRateList.Add(result);
                }
            }
            catch (Exception e)
            {
                throw new System.Exception(e.Message, e.InnerException);
            }

            // Run our tests against our six test cases including American and European values
            Assert.IsTrue(responseRateList.Count == 6, "The client did not generate/return all six test cases for the responseRateList object.");
            Assert.AreEqual("PALM BEACH GARDENS", responseRateList[0].City, "The City value did not match for responseRateList[0]");
            Assert.AreEqual((decimal)0.000, (decimal)responseRateList[0].CombinedDistrictRate, "The CombinedDistrictRate value did not match for responseRateList[0].");
            Assert.AreEqual("SANTA MONICA", responseRateList[1].City, "The city value did not match for responseRateList[1]");
            Assert.AreEqual((decimal)0.030, (decimal)responseRateList[1].CombinedDistrictRate, "The CombinedDistrictRate value did not match for responseRateList[1]");
            Assert.AreEqual("SANTA MONICA", responseRateList[2].City, "The city value did not match for responseRateList[2]");
            Assert.AreEqual(false, responseRateList[2].FreightTaxable, "The FreightTaxable value did not match for responseRateList[2]");
            Assert.AreEqual("WILLISTON", responseRateList[3].City, "The city value did not match for responseRateList[3]");
            Assert.AreEqual((decimal)0.010, (decimal)responseRateList[3].CityRate, "The CityRate value did not match for responseRateList[3]");
            Assert.AreEqual("CA", responseRateList[4].Country, "The Country value did not match for responseRateList[4]");
            Assert.AreEqual("NS", responseRateList[4].State, "The State value did not match for responseRateList[4]");
            Assert.AreEqual("United Kingdom", responseRateList[5].Name, "The Name value did not match for responseRateList[5]");
            Assert.AreEqual((decimal)0.200, (decimal)responseRateList[5].StandardRate, "The StandardRate value did not match for responseRateList[5]");
        }

        [TestMethod]
        public async Task TestTaxBySalesOrder()
        {
            // Arrange: Populate our fake locations and create our client consumer
            PopulateLocalListOfFakeSalesOrders();
            TaxServices service = new TaxServices();

            // Act: Run through all of our test cases by calling the service
            try
            {
                foreach (var order in orderList)
                {
                    Taxjar.TaxResponseAttributes result = await service.CalculateTaxForSalesOrder(order);
                    responseTaxList.Add(result);
                }
            }
            catch (Exception e)
            {
                throw new System.Exception(e.Message, e.InnerException);
            }

            // Run our tests against our six test cases including American and European values
            Assert.IsTrue(responseTaxList.Count == 1, "The client did not generate/return the test case for the responseTaxList object.");
            Assert.AreEqual("LOS ANGELES", responseTaxList[0].Jurisdictions.County, "The Jusisdiction.County value did not match for responseTaxList[0]");
            Assert.AreEqual((decimal)1.43, (decimal)responseTaxList[0].AmountToCollect, "The AmountToCollect value did not match for responseTaxList[0].");
            Assert.AreEqual("destination", responseTaxList[0].TaxSource, "The TaxSource value did not match for responseTaxList[0]");
            Assert.AreEqual((decimal)16.5, (decimal)responseTaxList[0].OrderTotalAmount, "The OrderTotalAmount value did not match for responseTaxList[0]");
            Assert.AreEqual((decimal)15.0, (decimal)responseTaxList[0].TaxableAmount, "The TaxableAmount value did not match for responseTaxList[0]");
        }

        // Populate our list of locations with some fake data
        private void PopulateLocalListOfFakeLocations()
        {
            Location location1 = new Location();  // United States (5 digit zipcode)
            Location location2 = new Location();  // United States (9 digit zipcode)
            Location location3 = new Location();  // United States (with optional paraters)
            Location location4 = new Location();  // United States (ZIP+4 w/ Street Address for Rooftop Accuracy)
            Location location5 = new Location();  // Canada 
            Location location6 = new Location();  // United Kingdom (European Union) 

            // US locations
            location1.zip = "33418";
            location2.zip = "90404-3370";
            location3.city = "Santa Monica";
            location3.state = "CA";
            location3.zip = "90404";
            location3.country = "US";
            location4.street = "312 Hurricane Lane";
            location4.city = "Williston";
            location4.state = "VT";
            location4.zip = "05495-2086";
            location4.country = "US";

            // Canada location
            location5.street = "433 Elizabeth St.";
            location5.city = "Port Morien";
            location5.state = "NA";
            location5.zip = "B1B5V7";
            location5.country = "CA";

            // United Kingdom location (UK doesn't have states)
            location6.street = "9817 Highfield Road";
            location6.city = "WALSALL";
            location6.zip = "WS586BK";
            location6.country = "UK";

            locationList.Add(location1);
            locationList.Add(location2);
            locationList.Add(location3);
            locationList.Add(location4);
            locationList.Add(location5);
            locationList.Add(location6);
        }

        // Populate our list of locations with some fake data
        private void PopulateLocalListOfFakeSalesOrders()
        {
            SalesOrder order1 = new SalesOrder();
            Data.Entities.NexusAddress address1 = new Data.Entities.NexusAddress();
            Note note1 = new Note();

            // US locations
            order1.from_country = "US";
            order1.from_zip = "92093";
            order1.from_state = "CA";
            order1.from_city = "La Jolla";
            order1.from_street = "9500 Gilman Drive";
            order1.to_country = "US";
            order1.to_zip = "90002";
            order1.to_state = "CA";
            order1.to_city = "Los Angeles";
            order1.to_street = "1335 E 103rd St";
            order1.amount = 15f;
            order1.shipping = 1.5f;

            // Our nexus address
            address1.id = "Main Location";
            address1.country = "US";
            address1.zip = "92093";
            address1.state = "CA";
            address1.city = "La Jolla";
            address1.street = "9500 Gilman Drive";

            // our note
            note1.id = "1";
            note1.quantity = 1;
            note1.product_tax_code = "20010";
            note1.unit_price = 15;
            note1.discount = 0;

            // Add our nexus address(s) and note(s) to their respective array
            order1.nexus_addresses = new Data.Entities.NexusAddress[1];
            order1.nexus_addresses[0] = address1;
            order1.notes = new Data.Entities.Note[1];
            order1.notes[0] = note1;
            orderList.Add(order1);
        }
    }
}
