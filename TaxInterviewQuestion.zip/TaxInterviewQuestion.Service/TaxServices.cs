﻿using System.Threading.Tasks;
using TaxInterviewQuestion.Core.Extensions;
using TaxInterviewQuestion.Data.Entities;
using Taxjar;

namespace TaxInterviewQuestion.Service
{
    public class TaxServices: ITaxServices
    {
        private ApiHelper service = new ApiHelper();

        public TaxServices()
        {
            service.InitializeApiClient();
        }

        public async Task<Taxjar.RateResponseAttributes> GetTaxRateForLocation(Location location)
        {
            try
            {
                if (location.IsZipOnlyLocation())
                    return await service.ApiClient.RatesForLocationAsync(location.zip);
                else
                    return await service.ApiClient.RatesForLocationAsync(location.zip, location);
            }
            catch(TaxjarException e)
            {
                throw new TaxjarException(System.Net.HttpStatusCode.BadRequest, e.TaxjarError, e.Message);
            }
        }

        public async Task<Taxjar.TaxResponseAttributes> CalculateTaxForSalesOrder(SalesOrder salesOrder)
        {
            try
            {
                return await service.ApiClient.TaxForOrderAsync(salesOrder);
            }
            catch (TaxjarException e)
            {
                throw new TaxjarException(System.Net.HttpStatusCode.BadRequest, e.TaxjarError, e.Message);
            }
        }
    }
}
