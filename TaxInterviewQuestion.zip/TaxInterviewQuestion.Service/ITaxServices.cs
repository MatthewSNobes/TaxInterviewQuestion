﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TaxInterviewQuestion.Data.Entities;

namespace TaxInterviewQuestion.Service
{
    public interface ITaxServices
    {
        public Task<Taxjar.RateResponseAttributes> GetTaxRateForLocation(Location location);
        public Task<Taxjar.TaxResponseAttributes> CalculateTaxForSalesOrder(SalesOrder salesOrder);
    }
}
