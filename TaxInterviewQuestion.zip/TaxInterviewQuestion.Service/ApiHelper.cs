﻿using System;
using System.Collections.Generic;
using System.Text;
using Taxjar;
using System.Configuration;

namespace TaxInterviewQuestion.Service
{
    public class ApiHelper
    {
        public TaxjarApi ApiClient { get; set; }

        public void InitializeApiClient()
        {
            ApiClient = new TaxjarApi(Properties.Resources.TaxJarAPIToken);
        }
    }
}
