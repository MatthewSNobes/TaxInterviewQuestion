﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using TaxInterviewQuestion.Data.Entities;
using Taxjar;
using TaxInterviewQuestion.Service;
using TaxInterviewQuestion.Core.Extensions;
using System;

namespace TaxInterviewQuestion.Pages
{
    public class IndexModel : PageModel
    {
        public List<Taxjar.RateResponseAttributes> responseList = new List<Taxjar.RateResponseAttributes>();
        private List<Location> locationList = new List<Location>();
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            this._logger = logger;
        }

        public async Task OnGet()
        {
            // Create our client consumer
            TaxServices service = new TaxServices();

            try
            {
                // Populate our fake locations and responses from web service
                PopulateLocalListOfFakeLocations();
                foreach (var location in locationList)
                {
                    Taxjar.RateResponseAttributes result = await service.GetTaxRateForLocation(location);
                    responseList.Add(result);
                }
            }
            catch(Exception e)
            {
                // Perform some kind of logging and display to user
                _logger.LogError(e.Message, e);
                throw new System.Exception(e.Message, e.InnerException);
            }
        }

        // Populate our list of locations with some fake data
        private void PopulateLocalListOfFakeLocations()
        {   
            Location location1 = new Location();  // United States (5 digit zipcode)
            Location location2 = new Location();  // United States (9 digit zipcode)
            Location location3 = new Location();  // United States (with optional paraters)
            Location location4 = new Location();  // United States (ZIP+4 w/ Street Address for Rooftop Accuracy)
            Location location5 = new Location();  // Canada 
            Location location6 = new Location();  // United Kingdom (European Union) 

            // US locations
            location1.zip = "33418";
            location2.zip = "90404-3370";
            location3.city = "Santa Monica";
            location3.state = "CA";
            location3.zip = "90404";
            location3.country = "US";
            location4.street = "312 Hurricane Lane";
            location4.city = "Williston";
            location4.state = "VT";
            location4.zip = "05495-2086";
            location4.country = "US";

            // Canada location
            location5.street = "433 Elizabeth St.";
            location5.city = "Port Morien";
            location5.state = "NA";
            location5.zip = "B1B5V7";
            location5.country = "CA";

            // United Kingdom location (UK doesn't have states)
            location6.street = "9817 Highfield Road";
            location6.city = "WALSALL";
            location6.zip = "WS586BK";
            location6.country = "UK";

            locationList.Add(location1);
            locationList.Add(location2);
            locationList.Add(location3);
            locationList.Add(location4);
            locationList.Add(location5);
            locationList.Add(location6);
        }
    }
}