﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using TaxInterviewQuestion.Data.Entities;
using Taxjar;
using TaxInterviewQuestion.Service;
using System;

namespace TaxInterviewQuestion
{
    public class IndexModel : PageModel
    {
        public List<Taxjar.TaxResponseAttributes> responseList = new List<Taxjar.TaxResponseAttributes>();
        private List<SalesOrder> orderList = new List<SalesOrder>();
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            this._logger = logger;
        }

        public async Task OnGet()
        {
            // Create our client consumer
            TaxServices service = new TaxServices();

            try
            {
                // Populate our fake locations and responses from web service 
                PopulateLocalListOfFakeSalesOrders();
                foreach (var order in orderList)
                {
                    Taxjar.TaxResponseAttributes result = await service.CalculateTaxForSalesOrder(order);
                    responseList.Add(result);
                }
            }
            catch (Exception e)
            {
                // Perform some kind of logging and display to user
                _logger.LogError(e.Message, e);
                throw new System.Exception(e.Message, e.InnerException);
            }
        }

        // Populate our list of locations with some fake data
        private void PopulateLocalListOfFakeSalesOrders()
        {
            SalesOrder order1 = new SalesOrder();  
            Data.Entities.NexusAddress address1 = new Data.Entities.NexusAddress();
            Note note1 = new Note();

            // US locations
            order1.from_country = "US";
            order1.from_zip = "92093";
            order1.from_state = "CA";
            order1.from_city = "La Jolla";
            order1.from_street = "9500 Gilman Drive";
            order1.to_country = "US";
            order1.to_zip = "90002";
            order1.to_state = "CA";
            order1.to_city = "Los Angeles";
            order1.to_street = "1335 E 103rd St";
            order1.amount = 15f;
            order1.shipping = 1.5f;

            // Our nexus address
            address1.id = "Main Location";
            address1.country = "US";
            address1.zip = "92093";
            address1.state = "CA";
            address1.city = "La Jolla";
            address1.street = "9500 Gilman Drive";

            // our note
            note1.id = "1";
            note1.quantity = 1;
            note1.product_tax_code = "20010";
            note1.unit_price = 15;
            note1.discount = 0;
            
            // Add our nexus address(s) and note(s) to their respective array
            order1.nexus_addresses = new Data.Entities.NexusAddress[1];
            order1.nexus_addresses[0] = address1;
            order1.notes = new Data.Entities.Note[1];
            order1.notes[0] = note1;
            orderList.Add(order1);   
        }
    }
}