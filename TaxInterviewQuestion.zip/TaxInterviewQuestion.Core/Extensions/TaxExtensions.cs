﻿using System;
using System.Collections.Generic;
using System.Text;
using TaxInterviewQuestion.Data.Entities;
using Taxjar;

namespace TaxInterviewQuestion.Core.Extensions
{
    public static class TaxExtensions
    {
        // Used to determine if we need to send single parameter or two
        public static bool IsZipOnlyLocation(this Location location)
        {
            if (location.street == null && location.city == null && location.state == null
                && location.country == null)
                return true;
            else
                return false;

        }
    }
}