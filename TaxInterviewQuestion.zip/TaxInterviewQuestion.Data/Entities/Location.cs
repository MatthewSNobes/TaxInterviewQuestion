﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TaxInterviewQuestion.Data.Entities
{
    public class Location
    {
        [StringLength(2)]
        public string country { get; set; }  // conditional Two-letter ISO country code for given location.

        [Required]
        [RegularExpression(@"^[0-9]{5}(?:-[0-9]{4})?$", ErrorMessage = "Invalid Zip Code")]
        public string zip { get; set; }  // required Postal code for given location (5-Digit ZIP or ZIP+4).

        [StringLength(2)]
        public string state { get; set; }  // optional Two-letter ISO state code for given location.

        [MinLength(3), MaxLength(50)]
        public string city { get; set; }  // optional City for given location.

        [MinLength(3), MaxLength(50)]
        public string street { get; set; }  // optional Street address for given location. View Note
    }
}