﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxInterviewQuestion.Data.Entities
{
    public class SalesOrder
    {
        public string from_country { get; set; }  // string optional, Two-letter ISO country code of the country where the order shipped from.View Note
        public string from_zip { get; set; }  // string optional Postal code where the order shipped from (5-Digit ZIP or ZIP+4).
        public string from_state { get; set; }  // string optional Two-letter ISO state code where the order shipped from.
        public string from_city { get; set; }  // string optional, City where the order shipped from.
        public string from_street { get; set; }  // string optional, Street address where the order shipped from.
        public string to_country { get; set; }  // string required, Two-letter ISO country code of the country where the order shipped to.
        public string to_zip { get; set; }  // string conditional, Postal code where the order shipped to (5-Digit ZIP or ZIP+4).
        public string to_state { get; set; }  // string conditional, Two-letter ISO state code where the order shipped to.
        public string to_city { get; set; }  // string optional, City where the order shipped to.
        public string to_street { get; set; }  // string optional, Street address where the order shipped to.View Note
        public float amount { get; set; }  // float optional, Total amount of the order, excluding shipping. View Note
        public float shipping { get; set; }  // float required, Total amount of shipping for the order.
        public string customerId { get; set; } // string optional, Unique identifier of the given customer for exemptions.
        public string exemption_type { get; set; } // string optional, Type of exemption for the order: wholesale, government, marketplace, other, or non_exempt.View Note
        public NexusAddress[] nexus_addresses { get; set; }  // Array of NexusAddresses 
        public Note[] notes { get; set; }  // Array of Notes
    }
}